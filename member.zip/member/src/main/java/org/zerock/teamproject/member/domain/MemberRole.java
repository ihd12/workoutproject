package org.zerock.teamproject.member.domain;

public enum MemberRole {
    USER, ADMIN

}
